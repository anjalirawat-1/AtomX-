# AtomX — Conveyor Intelligence Frontend

A self-contained interactive dashboard prototype for SIH 2026 problem statement SIH26008.

## What is included
- Real-time conveyor overview with animated belt and ore flow
- Encoder + magnetic-gate splice tracking UI
- GNHI (General Normal Health Index) gauge
- Live condition telemetry and vibration trend
- Ultrasonic / EMAT internal inspection screen
- Laser + inductive belt tracking screen
- Predictive analytics and operator-readable model factors
- Early-warning alert center
- Condition-based maintenance planner
- Demo Normal / Warning / Critical scenarios
- Responsive layout for laptop and mobile

## Run locally
No build step is required.

Option 1: double-click `index.html`.

Option 2 (recommended):
```bash
python -m http.server 5500
```
Then open `http://localhost:5500`.

## Deploy
This folder can be deployed directly as a static site on Vercel, Netlify, GitHub Pages or Render Static Site.

## Backend integration points
The current values are simulated in `app.js` so the SIH demo works without hardware. Replace the `scenarioValues()` function / timer with your WebSocket or REST API data.

Suggested payload shape:
```json
{
  "beltSpeed": 3.42,
  "vibration": 2.8,
  "temperature": 52.4,
  "edgeOffset": 4.6,
  "acousticRms": 61,
  "spliceStretch": 0.8,
  "gnhi": 92,
  "status": "normal"
}
```

## Design notes
The UI intentionally uses an industrial control-room visual language: restrained color, dense telemetry, compact type, subtle motion and clear operator states rather than generic SaaS cards.
