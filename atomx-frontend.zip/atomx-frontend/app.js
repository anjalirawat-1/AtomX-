const $ = (q, root = document) => root.querySelector(q);
const $$ = (q, root = document) => [...root.querySelectorAll(q)];

const state = {
  scenario: 'normal',
  sound: true,
  selectedSplice: 'J-01',
  chart: Array.from({ length: 60 }, (_, i) => 2.55 + Math.sin(i / 6) * 0.18 + Math.random() * 0.22),
  alerts: 2,
};

const viewMeta = {
  overview: ['OVERVIEW', 'Conveyor health overview'],
  splice: ['JOINT HEALTH', 'Splice health register'],
  inspection: ['INTERNAL INSPECTION', 'Ultrasonic / EMAT inspection'],
  tracking: ['BELT TRACKING', 'Alignment & edge tracking'],
  analytics: ['PREDICTIVE ANALYTICS', 'Predictive health model'],
  alerts: ['ALERTS', 'Alert center'],
  maintenance: ['MAINTENANCE', 'Maintenance planner'],
};

function showView(name) {
  $$('.view').forEach(v => v.classList.toggle('active', v.id === `view-${name}`));
  $$('.nav-item').forEach(b => b.classList.toggle('active', b.dataset.view === name));
  $('#breadcrumb').textContent = viewMeta[name][0];
  $('#pageTitle').textContent = viewMeta[name][1];
  $('#sidebar').classList.remove('open');
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

$$('.nav-item').forEach(btn => btn.addEventListener('click', () => showView(btn.dataset.view)));
$$('[data-jump]').forEach(btn => btn.addEventListener('click', () => showView(btn.dataset.jump)));
$('#mobileMenu').addEventListener('click', () => $('#sidebar').classList.toggle('open'));

document.addEventListener('click', (e) => {
  if (window.innerWidth <= 820 && $('#sidebar').classList.contains('open') && !e.target.closest('#sidebar') && !e.target.closest('#mobileMenu')) {
    $('#sidebar').classList.remove('open');
  }
});

function toast(title, text) {
  const el = document.createElement('div');
  el.className = 'toast';
  el.innerHTML = `<strong>${title}</strong><span>${text}</span>`;
  $('#toastStack').appendChild(el);
  setTimeout(() => el.remove(), 3600);
}

function setScenario(mode) {
  state.scenario = mode;
  document.body.classList.remove('scenario-normal', 'scenario-warning', 'scenario-critical');
  document.body.classList.add(`scenario-${mode}`);
  $$('.scenario').forEach(b => b.classList.toggle('active', b.dataset.scenario === mode));

  const presets = {
    normal: { gnhi: 92, badge: 'NORMAL', note: 'Multi-sensor indicators are inside the stable operating envelope.', title: 'Continue normal operation', rec: 'No maintenance intervention is required. Re-check splice J-03 during the planned shift inspection.', confidence: '94%', inspect: '6 h 18 m' },
    warning: { gnhi: 72, badge: 'WARNING', note: 'Tracking drift and splice stretch are trending upward. Operator review is advised.', title: 'Plan a controlled inspection', rec: 'Inspect J-03 and Zone C guide rollers during the next low-load window.', confidence: '92%', inspect: '1 h 42 m' },
    critical: { gnhi: 41, badge: 'CRITICAL', note: 'Multiple indicators are outside the safe envelope. Escalate before continued operation.', title: 'Reduce load and inspect J-03', rec: 'Joint stretch and vibration are rising together. Prepare a controlled stop if the trend persists.', confidence: '96%', inspect: 'Now' },
  };
  const p = presets[mode];
  $('#gnhiValue').textContent = p.gnhi;
  $('#gaugeValue').style.strokeDasharray = `${p.gnhi} 100`;
  $('#gnhiBadge').textContent = p.badge;
  $('#gnhiBadge').className = `badge ${mode === 'normal' ? 'ok' : mode === 'warning' ? 'warn' : 'critical'}`;
  $('#gnhiNote').textContent = p.note;
  $('#recommendationTitle').textContent = p.title;
  $('#recommendationText').textContent = p.rec;
  $('#modelConfidence').textContent = p.confidence;
  $('#nextInspection').textContent = p.inspect;
  $('#criticalAlert').classList.toggle('demo-hidden', mode !== 'critical');
  $('#alertPill').textContent = mode === 'critical' ? 3 : 2;

  if (mode === 'warning') toast('Demo scenario changed', 'Warning conditions are now being simulated.');
  if (mode === 'critical') toast('Critical demo scenario', 'Joint deterioration pattern injected for demonstration.');
}

$$('.scenario').forEach(btn => btn.addEventListener('click', () => setScenario(btn.dataset.scenario)));

function scenarioValues() {
  const noise = (mag = 1) => (Math.random() - .5) * mag;
  if (state.scenario === 'normal') return {
    speed: 3.42 + noise(.06), vib: 2.8 + noise(.25), temp: 52.4 + noise(.5), edge: 4.6 + noise(1.0), acoustic: 61 + noise(2), stretch: .8 + noise(.08)
  };
  if (state.scenario === 'warning') return {
    speed: 3.28 + noise(.12), vib: 4.6 + noise(.5), temp: 59.8 + noise(1.1), edge: 12.4 + noise(2.6), acoustic: 68 + noise(4), stretch: 1.85 + noise(.16)
  };
  return {
    speed: 2.92 + noise(.2), vib: 7.4 + noise(.9), temp: 71.6 + noise(2), edge: 26.8 + noise(5), acoustic: 79 + noise(5), stretch: 3.4 + noise(.3)
  };
}

function updateTelemetry() {
  const v = scenarioValues();
  $('#speedVal').textContent = v.speed.toFixed(2);
  $('#vibVal').textContent = v.vib.toFixed(1);
  $('#tempVal').textContent = v.temp.toFixed(1);
  $('#edgeVal').textContent = Math.abs(v.edge).toFixed(1);
  $('#acousticVal').textContent = Math.round(v.acoustic);
  $('#stretchVal').textContent = v.stretch.toFixed(1);
  $('#trackOffset').textContent = `${v.edge >= 0 ? '+' : ''}${v.edge.toFixed(1)}`;
  $('#beltEdgeLine').style.left = `${Math.max(8, Math.min(92, 50 + v.edge / 80 * 50))}%`;

  const classFor = (x, warn, crit) => x >= crit ? 'critical' : x >= warn ? 'rising' : 'stable';
  $('#vibTrend').className = `trend ${classFor(v.vib, 4, 6.5)}`;
  $('#tempTrend').className = `trend ${classFor(v.temp, 58, 68)}`;
  $('#edgeTrend').className = `trend ${classFor(Math.abs(v.edge), 10, 22)}`;
  $('#stretchTrend').className = `trend ${classFor(v.stretch, 1.5, 2.8)}`;
  $('#vibTrend').textContent = v.vib > 6.5 ? '● critical' : v.vib > 4 ? '● rising' : '● stable';
  $('#tempTrend').textContent = v.temp > 68 ? '● high' : v.temp > 58 ? '● elevated' : '● stable';
  $('#edgeTrend').textContent = Math.abs(v.edge) > 22 ? '● severe drift' : Math.abs(v.edge) > 10 ? '● drifting' : '● centered';
  $('#stretchTrend').textContent = v.stretch > 2.8 ? '● critical' : v.stretch > 1.5 ? '● watch' : '● nominal';
  $('#trackStatus').textContent = Math.abs(v.edge) > 22 ? 'Severe misalignment' : Math.abs(v.edge) > 10 ? 'Drift / watch' : 'Centered / stable';

  state.chart.push(v.vib);
  state.chart.shift();
  drawTrend();
}

function drawTrend() {
  const w = 720, h = 220, min = 1.5, max = 8.5;
  const pts = state.chart.map((v, i) => {
    const x = i / (state.chart.length - 1) * w;
    const y = h - ((v - min) / (max - min) * (h - 20)) - 8;
    return [x, Math.max(6, Math.min(h - 4, y))];
  });
  $('#linePath').setAttribute('points', pts.map(p => p.join(',')).join(' '));
  $('#areaPath').setAttribute('d', `M ${pts[0][0]} ${h} L ${pts.map(p => p.join(' ')).join(' L ')} L ${pts.at(-1)[0]} ${h} Z`);
  $('#chartPeak').textContent = `peak ${Math.max(...state.chart).toFixed(1)}`;
}

drawTrend();
setInterval(updateTelemetry, 1200);
setInterval(() => $('#lastSync').textContent = 'now', 5000);

function updateClock() {
  const d = new Date();
  $('#simClock').textContent = d.toLocaleTimeString('en-GB', { hour12: false });
}
updateClock(); setInterval(updateClock, 1000);

$$('.splice-marker').forEach(btn => btn.addEventListener('click', () => {
  $$('.splice-marker').forEach(b => b.classList.remove('selected'));
  btn.classList.add('selected');
  state.selectedSplice = btn.dataset.splice;
  $('#selectedSplice').textContent = state.selectedSplice;
  const status = state.selectedSplice === 'J-03' ? 'Slow stretch trend · review next shift' : 'Stable · no abnormal stretch';
  $('#selectedSpliceState').textContent = status;
}));

function buildBars() {
  const vals = [42,44,43,46,47,51,50,55,58,61,63,66,71,75];
  $('#stretchBars').innerHTML = vals.map(v => `<i style="height:${v}%" title="${v}"></i>`).join('');
}
buildBars();

function drawScan() {
  const c = $('#scanCanvas');
  const ctx = c.getContext('2d');
  ctx.clearRect(0,0,c.width,c.height);
  ctx.fillStyle = '#07090b'; ctx.fillRect(0,0,c.width,c.height);
  for (let x=0;x<c.width;x+=6) {
    const base = 110 + Math.sin(x/35)*8 + Math.random()*9;
    const grad = ctx.createLinearGradient(0,40,0,330);
    grad.addColorStop(0,'rgba(90,137,160,.02)');
    grad.addColorStop(.35,'rgba(83,133,154,.5)');
    grad.addColorStop(.55,'rgba(92,145,166,.16)');
    grad.addColorStop(1,'rgba(28,56,69,.02)');
    ctx.strokeStyle=grad; ctx.lineWidth=3;
    ctx.beginPath(); ctx.moveTo(x,base); ctx.lineTo(x+4,base+55+Math.random()*35); ctx.stroke();
    if (x>570 && x<640 && Math.random()>.45){ctx.fillStyle='rgba(242,191,74,.45)';ctx.fillRect(x,205+Math.random()*35,4,3)}
  }
  ctx.strokeStyle='rgba(133,190,212,.55)'; ctx.lineWidth=2;
  ctx.beginPath();
  for(let x=0;x<c.width;x+=5){const y=92+Math.sin(x/22)*3+Math.random()*2; x===0?ctx.moveTo(x,y):ctx.lineTo(x,y)}
  ctx.stroke();
}
drawScan();

$('#runScan').addEventListener('click', () => {
  const cursor = $('#scanCursor');
  cursor.classList.remove('running'); void cursor.offsetWidth; cursor.classList.add('running');
  $('#scanBadge').textContent = 'SCANNING'; $('#scanBadge').className='badge warn';
  setTimeout(()=>{ $('#scanBadge').textContent='COMPLETE'; $('#scanBadge').className='badge ok'; drawScan(); toast('Inspection complete','UT/EMAT scan finished. One weak echo cluster flagged for review.'); }, 2850);
});

function buildForecast(){
  const el = $('#forecastChart');
  const points = [92,92,91,91,90,90,90,89,89,88,88,87,87,86];
  const coords = points.map((v,i)=>[i/(points.length-1)*640,200-((v-70)/30*170)]);
  el.innerHTML = `<svg viewBox="0 0 640 210" preserveAspectRatio="none"><path d="M ${coords[0][0]} 200 L ${coords.map(p=>p.join(' ')).join(' L ')} L ${coords.at(-1)[0]} 200 Z" fill="rgba(255,122,26,.08)"/><polyline points="${coords.map(p=>p.join(',')).join(' ')}" fill="none" stroke="#ff7a1a" stroke-width="2" vector-effect="non-scaling-stroke"/><line x1="0" y1="154" x2="640" y2="154" stroke="#6a5535" stroke-dasharray="5 6"/><text x="8" y="147" fill="#78684e" font-size="8" font-family="IBM Plex Mono">WARNING 78</text></svg>`;
}
buildForecast();

$('#soundToggle').addEventListener('click', (e) => {
  state.sound = !state.sound;
  e.currentTarget.style.color = state.sound ? '#98a2ab' : '#ff7a1a';
  toast('Alert sound', state.sound ? 'Operator alert tone enabled.' : 'Operator alert tone muted.');
});

$$('.ack-button').forEach(btn => btn.addEventListener('click', () => {
  btn.closest('.alert-card').classList.add('acknowledged');
  btn.textContent = 'Acknowledged'; btn.disabled = true;
  toast('Alert acknowledged', 'Event remains available in the audit trail.');
}));

$('#ackAll').addEventListener('click', () => {
  $$('.alert-card:not(.demo-hidden)').forEach(card => {
    card.classList.add('acknowledged'); const btn=$('.ack-button',card); btn.textContent='Acknowledged'; btn.disabled=true;
  });
  toast('Visible alerts acknowledged', 'All visible events have been marked as reviewed.');
});

const modal = $('#modalBackdrop');
function openModal(){modal.hidden=false; setTimeout(()=>$('#noteText').focus(),20)}
function closeModal(){modal.hidden=true}
$('#createTask').addEventListener('click',openModal);
$('#newWorkOrder').addEventListener('click',openModal);
$('#modalClose').addEventListener('click',closeModal); $('#modalCancel').addEventListener('click',closeModal);
$('#modalBackdrop').addEventListener('click',e=>{if(e.target===modal)closeModal()});
$('#modalSave').addEventListener('click',()=>{closeModal();toast('Maintenance note saved','Note added to the operator log for Line 03.');});

$('#scanAllSplices').addEventListener('click', () => {
  toast('Splice pass check started', 'Encoder and magnetic gate synchronization is being verified.');
  const btn = $('#scanAllSplices'); const old=btn.textContent; btn.textContent='Checking…'; btn.disabled=true;
  setTimeout(()=>{btn.textContent=old;btn.disabled=false;toast('Splice pass check complete','All 4 joints detected; J-03 remains on watch.');},1800);
});

$('#siteButton').addEventListener('click',()=>toast('Site selector','Prototype is currently configured for Iron Ore Plant — Line 03.'));
$$('.event-row').forEach(r=>r.addEventListener('click',()=>showView(r.classList.contains('warning-event')?'alerts':'inspection')));

setScenario('normal');
